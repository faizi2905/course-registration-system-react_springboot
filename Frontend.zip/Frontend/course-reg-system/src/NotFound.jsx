function NotFound(){
    return(
        <>
        <h2>Error 404 - Page Not Found</h2>
        </>
    )
}

export default NotFound