function NotFound(){
    return(
        <>
        <h2>You don't have access</h2>
        </>
    )
}

export default NotFound